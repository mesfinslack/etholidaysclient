import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customized-tour',
  templateUrl: './customized-tour.component.html',
  styleUrls: ['./customized-tour.component.css']
})
export class CustomizedTourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
