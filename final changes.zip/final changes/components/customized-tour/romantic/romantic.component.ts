import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-romantic',
  templateUrl: './romantic.component.html',
  styleUrls: ['./romantic.component.css']
})
export class RomanticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
