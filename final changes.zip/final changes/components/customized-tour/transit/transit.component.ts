import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tranzit',
  templateUrl: './transit.component.html',
  styleUrls: ['./transit.component.css']
})
export class TransitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
