import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-national-musuem-and-ethio-coffee',
  templateUrl: './national-musuem-and-ethio-coffee.component.html',
  styleUrls: ['./national-musuem-and-ethio-coffee.component.css']
})
export class NationalMusuemAndEthioCoffeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
