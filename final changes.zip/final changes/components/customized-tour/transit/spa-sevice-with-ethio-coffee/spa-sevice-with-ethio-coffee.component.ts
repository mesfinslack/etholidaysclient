import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spa-sevice-with-ethio-coffee',
  templateUrl: './spa-sevice-with-ethio-coffee.component.html',
  styleUrls: ['./spa-sevice-with-ethio-coffee.component.css']
})
export class SpaSeviceWithEthioCoffeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
