import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ethiopian-traditional-dinner-and-cultural-music-with-coffee',
  templateUrl: './ethiopian-traditional-dinner-and-cultural-music-with-coffee.component.html',
  styleUrls: ['./ethiopian-traditional-dinner-and-cultural-music-with-coffee.component.css']
})
export class EthiopianTraditionalDinnerAndCulturalMusicWithCoffeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
