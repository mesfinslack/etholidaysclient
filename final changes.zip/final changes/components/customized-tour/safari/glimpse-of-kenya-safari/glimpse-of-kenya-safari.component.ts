import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glimpse-of-kenya-safari',
  templateUrl: './glimpse-of-kenya-safari.component.html',
  styleUrls: ['./glimpse-of-kenya-safari.component.css']
})
export class GlimpseOfKenyaSafariComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
