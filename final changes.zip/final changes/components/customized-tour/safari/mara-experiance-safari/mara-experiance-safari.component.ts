import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mara-experiance-safari',
  templateUrl: './mara-experiance-safari.component.html',
  styleUrls: ['./mara-experiance-safari.component.css']
})
export class MaraExperianceSafariComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
