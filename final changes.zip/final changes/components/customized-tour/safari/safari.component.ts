import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-safari',
  templateUrl: './safari.component.html',
  styleUrls: ['./safari.component.css']
})
export class SafarisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
