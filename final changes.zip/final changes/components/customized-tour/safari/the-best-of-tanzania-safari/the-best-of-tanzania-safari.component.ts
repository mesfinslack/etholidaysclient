import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-the-best-of-tanzania-safari',
  templateUrl: './the-best-of-tanzania-safari.component.html',
  styleUrls: ['./the-best-of-tanzania-safari.component.css']
})
export class TheBestOfTanzaniaSafariComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
