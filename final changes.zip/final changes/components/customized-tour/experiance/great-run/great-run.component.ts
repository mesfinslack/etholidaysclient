import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-great-run',
  templateUrl: './great-run.component.html',
  styleUrls: ['./great-run.component.css']
})
export class GreatRunComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
