import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balloon',
  templateUrl: './balloon.component.html',
  styleUrls: ['./balloon.component.css']
})
export class BalloonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
