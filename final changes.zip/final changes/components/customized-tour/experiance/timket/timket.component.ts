import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timket',
  templateUrl: './timket.component.html',
  styleUrls: ['./timket.component.css']
})
export class TimketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
