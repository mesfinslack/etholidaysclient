import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eritrean',
  templateUrl: './eritrean.component.html',
  styleUrls: ['./eritrean.component.css']
})
export class EritreanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
